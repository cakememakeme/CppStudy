﻿#include "stdafx.h"

#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <iomanip>

#include <sstream>
#include <fstream>

void PrintIntegers(std::istream& in, std::ostream& out);
void PrintMaxFloat(std::istream& in, std::ostream& out);
bool fileExists(const char *fileName);
void padTo(std::string &str, const size_t num, const char paddingChar);

int main()
{
	if (fileExists("PrintIntegersIn.txt") == false)
	{
		std::cout << "파일 없음" << std::endl;
	}
	std::ifstream inInt("PrintIntegersIn.txt");
	std::ofstream outInt("PrintIntegersOut.txt");
	PrintIntegers(inInt, outInt);

	if (fileExists("PrintMaxFloatIn.txt") == false)
	{
		std::cout << "파일 없음" << std::endl;
	}
	std::ifstream inFloat("PrintMaxFloatIn.txt");
	std::ofstream outFloat("PrintMaxFloatOut.txt");
	PrintMaxFloat(inFloat, outFloat);
	return 0;
}

bool fileExists(const char *fileName)
{
	std::ifstream infile(fileName);
	return infile.good();
}

void padTo(std::string &str, const size_t num, const char paddingChar)
{
	if (num > str.size())
		str.insert(0, num - str.size(), paddingChar);
}

void PrintIntegers(std::istream& in, std::ostream& out)
{

	//입력
	//문자열을 읽고 정수를 vector에 저장
	std::vector<int> nums;
	while (in.peek() != EOF)
	{
		std::string line;
		std::string separateStr;
		std::getline(in, line);
		for (auto& it : line)
		{
			if (it >= '0' && it <= '9')
			{
				separateStr += it;
			}
			else if (separateStr.empty() == false)
			{
				nums.push_back(stoi(separateStr));
				separateStr.clear();
			}
		}
		if (separateStr.empty() == false)
		{
			nums.push_back(stoi(separateStr));
		}
	}

	//출력
	out << "         oct        dec      hex" << std::endl
		<< "------------ ---------- --------" << std::endl;

	for (auto& it : nums)
	{
		//8진수 변환 및 입력
		char oct[15] = { 0 };
		_itoa_s(it, oct, 8);
		std::string octStr(oct);
		padTo(octStr, 12, ' ');
		octStr += ' ';
		out << octStr;

		//10진수
		std::string decStr(std::to_string(it));
		padTo(decStr, 10, ' ');
		decStr += ' ';
		out << decStr;

		//16진수 변환 및 입력
		char hex[10] = { 0 };
		_itoa_s(it, hex, 16);
		std::string hexStr(hex);
		for (auto& it : hexStr)
		{
			it = toupper(it);
		}
		padTo(hexStr, 8, ' ');
		out << hexStr << std::endl;
	}
}

/* 이제 PrintMaxFloat */

void PrintMaxFloat(std::istream& in, std::ostream& out)
{
	//입력
	std::vector<double> nums;
	while (in.peek() != EOF)
	{
		std::string line;
		std::string separateStr;
		int16_t sign = 1;
		std::getline(in, line);
		for (auto& it : line)
		{
			if ((it >= '0' && it <= '9') || it == '.')
			{
				if (separateStr.empty() == true && it == '.')
				{
					continue;
				}
				separateStr += it;
			}
			else if (separateStr.empty() == false)
			{
				nums.push_back(stof(separateStr) * sign);
				separateStr.clear();
			}
			if (it == '-')
			{
				sign *= -1;
			}
			else if (it == '+')
			{
				sign = 1;
			}
		}
		if (separateStr.empty() == false)
		{
			nums.push_back(stof(separateStr) * sign);
		}
	}

	//출력
	float maxNum = nums[0];
	std::string maxStr;
	std::string numStr;
	std::stringstream ss;
	for (auto& it : nums)
	{
		//최댓값
		float itNum = it;
		if (maxNum < itNum)
		{
			maxNum = itNum;
			maxStr = it;
		}

		out << "     ";
		if (it < 0)
		{
			out << '-';
			it *= -1;
		}
		else
		{
			out << '+';
		}

		//소수점 3자리수까지 고정, 문자열 변환 후 출력 
		ss << std::fixed << std::setprecision(3) << it;
		numStr = ss.str();
		padTo(numStr, 14, ' ');
		out << numStr << std::endl;

		numStr.clear();
		ss.str("");
		ss.clear();
	}

	out << "max: ";
	if (maxNum < 0)
	{
		out << '-';
		maxNum *= -1;
	}
	else
	{
		out << '+';
	}
	ss << std::fixed << std::setprecision(3) << maxNum;
	numStr = ss.str();
	padTo(numStr, 14, ' ');
	out << numStr << std::endl;
}